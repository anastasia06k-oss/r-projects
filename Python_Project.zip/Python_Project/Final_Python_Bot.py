import telebot
import random
from telebot import types 
from datetime import datetime
import re
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

daily_random_drinks = {}

bar_description = f"\n\n<b>Imbibe Cocktail Bar</b> — легендарный питерский бар, сделавший «коктейль» синонимом Петербурга. Уже более 10 лет мы — главный ориентир для ценителей, бескомпромиссно сохраняя качество продуктов, рецептов и наше фирменное рок-н-рольное гостеприимство. \n\nМы ежегодно покоряем новых гостей, входим в топы лучших баров страны и остаёмся в медиа как символ городской коктейльной культуры. Наша атмосфера — игра контрастов, где каждый находит то, что зовёт его обратно."
drinks_list = ['Sorrel Smash', 
               "Smoky Pill", 
               'Porn Producer', 
               'Spanish Breakfast', 
               'Double Bubble', 
               'TikTok Ice Tea', 
               'Plumpolitan', 
               "My God. It's Green!", 
               'Italian Touch', 
               'Fig\'n\'Foam', 
               'Sawit Tiki', 
               'Strawberry Lava', 
               'Red Hem', 
               'Cocojito', 
               'Honey, Meloni', 
               'Fizzy Peppy', 
               'Die Hard', 
               'Lollipop 75', 
               'Eastern Sky', 
               'PEACH PACING', 
               'Humpty Dumpty', 
               'Kalkutta Cobbler', 
               'Negroni', 
               'Campari Spritz', 
               'Arancioni', 
               'Bitter Sparkle',
               ]
drinks_description = {
    "PEACH PACING": ["Освежающий коктейль на виски с мягкими фруктовыми нотами и мятной свежестью.", "виски, персик, мята, тоник", "средняя", "сладкий, фруктовые ноты, освежающий"],
  "HUMPTY DUMPTY": ["Нежный сливочно-фруктовый коктейль с экзотическим вкусом маракуйи и ванильной сладостью.", "водка, маракуйя, ваниль, домашний advocaat", "высокая", "сладкий, фруктовые ноты, освежающий"],
  "KALKUTTA COBBLER": ["Смелый и пикантный коктейль с дымными нотами мескаля и неожиданной пряностью карри.", "херес, ананас, карри, мескаль", "средняя", "горький, пряный, согревающий"],
  "DOUBLE BUBBLE": ["Игривый и лёгкий коктейль с ярким вкусом жевательной резинки и нежными фруктовыми оттенками.", "джин Bickens, персик, айва, бабл-гам, тоник", "низкая", "сладкий, фруктовый, освежающий"],
  "TIKTOK ICE TEA": ["Освежающий айс-ти на основе рома с пикантной кислинкой чёрного лайма и лёгкой пряностью.", "ром, чёрный лайм, сироп Coca, пряный биттер, содовая", "низкая", "кислый, пряный, освежающий"],
  "PLUMPOLITAN": ["Элегантный и фруктовый коктейль с глубоким вкусом сливы и вишни и тёплым перцовым финалом.", "водка, слива, вишня, чёрный перец", "средняя", "сладкий, пряный, согревающий"],
  "MY GOD. IT'S GREEN!": ["Необычный и свежий коктейль с сочным вкусом груши, анисовыми нотами и лёгкой травянистостью сельдерея.", "водка, груша, бадьян, сельдерей", "средняя", "сладкий, пряный, освежающий"],
  "NEGRONI": ["Классический, брутальный и сбалансированный биттер-коктейль с горьковато-травяным профилем.", "биттер Campari, джин Bickens, вермут Cinzano Rosso", "высокая", "горький, классический, согревающий"],
  "CAMPARI SPRITZ": ["Лёгкий, игристый и освежающий аперитив с характерной горчинкой Campari и пузырьками.", "биттер Campari, игристое вино, содовая", "низкая", "горький, классический, освежающий"],
  "ARANCIONI": ["Богатый и сложный коктейль с горьковатыми цитрусовыми нотами и шоколадным послевкусием.", "биттер Campari, джин Bickens, красный апельсин, какао", "средняя", "горький, фруктовый, согревающий"],
  "BITTER SPARKLE": ["Игристое и пикантное удовольствие с цитрусовой яркостью и тёплыми нотами тмина.", "биттер Campari, игристое вино, цитрусы, тмин", "низкая", "горький, пряный, согревающий"],
  "SORREL SMASH": ["Яркий и ароматный смаш с тропической маракуйей, пряностью кардамона и травянистой кислинкой щавеля.", "джин Bickens, маракуйя, кардамон, щавель", "средняя", "кислый, фруктовый, освежающий"],
  "SMOKY PILL": ["Насыщенный, дымный и согревающий коктейль с глубоким вкусом копчёного чая и имбирной остротой.", "виски, копчёный чай, специи, имбирь, белок", "высокая", " пряный, классический, согревающий"],
  "PORN PRODUCER": ["Соблазнительно-нежный коктейль с бархатной текстурой, миндально-ванильным ароматом и фруктовой сердцевиной.", "водка, цитрусовый аперитив, ваниль, персик, миндаль, белок", "средняя", "сладкий, фруктовый, согревающий"],
  "SPANISH BREAKFAST": ["Тёплый и уютный коктейль, напоминающий о испанском утре, с нотами апельсина, корицы и хереса.", "джин Bickens, апельсин, корица, кардамон, херес", "средняя", "горький, пряный, согревающий"],
  "RED HEM": ["Сочный и летний коктейль со вкусом спелого арбуза, красного апельсина и лёгкой терпкостью черёмухи.", "ром, красный апельсин, арбуз, черёмуха", "средняя", "сладкий, ягодный, освежающий"], 
  "COCOJITO": ["Тропический и бодрящий коктейль, переносящий на пляж, с кокосовой сладостью и лаймовой свежестью.", "кашаса, кокос, лайм, мята", "средняя", "сладкий, фруктовый, освежающий"],
  "HONEY, MELONI": ["Медово-нежный и мягкий коктейль с ярким вкусом дыни и зерновыми оттенками.", "джин Bickens, дыня, мед, злаки", "средняя", "сладкий, фруктовый, освежающий"],
  "ITALIAN TOUCH": ["Элегантный и цветочный коктейль с лёгкой горчинкой аперитива и нежным ароматом апельсиновых цветов.", "джин Bickens, розовый аперитив, вода цветков апельсина", "средняя", "горький, пряный, освежающий"],
  "FIG'N'FOAM": ["Бодрящий и острый коктейль с яркой цитрусовой основой и согревающим имбирным финалом.", "водка, инжир, лайм, имбирь", "средняя", "кислый, цитрусовый, согревающий"], 
  "SAWIT TIKI": ["Праздничный и беззаботный тропический коктейль, ассоциирующийся с отдыхом на островах.", "ром, кокос, ананас", "средняя", "сладкий, фруктовый, освежающий"], 
  "STRAWBERRY LAVA": ["Страстный и контрастный коктейль: сладость клубники и апельсина встречается с жгучим халапеньо.", "Espolon Blanco, апельсин, клубника, халапеньо", "средняя", "сладкий, ягодный, согревающий"],
  "FIZZY PEPPY": ["Пикантный и газированный коктейль с необычным сочетанием копчёной паприки, ананаса и томата.", "Espolon Blanco, ананас, копчёная паприка, томат", "средняя", "горький, пряный, согревающий"], 
  "DIE HARD": ["Насыщенный, десертный и брутальный коктейль для истинных ценителей с глубокими орехово-кофейными нотами.", "виски, грецкий орех, кофе, карамель, бобы тонка", "высокая", "сладкий, пряный, согревающий"], 
  "LOLLIPOP 75": ["Игривый и элегантный коктейль с ягодным вкусом барбариса, сладостью личи и игристым финалом.", "джин Bickens, барбарис, улун, личи, игристое вино", "низкая", "сладкий, ягодный, освежающий"], 
  "EASTERN SKY": ["Нежный и поэтичный коктейль с лёгким цветочным ароматом сакуры и кислинкой лесных ягод.", "джин Bickens, сакура, лесные ягоды", "средняя", "кислый, ягодный, освежающий"]
  } 
bot = telebot.TeleBot("7026472037:AAEh-Qc0TwFuBHq8qNrSqmg2ckvM_Ll76ms")

@bot.message_handler(commands = ['start'])
def main(message):
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton('Открыть барную карту', url = 'https://imbibe-crew.ru/imbibe?utm_referer=geoadv_direct&utm_ya_campaign=39645459166&yabizcmpgn=52717697&utm_source=geoadv_direct&utm_candidate=61140145045&utm_content=17419526962&etext=2202.hqc6xBE7mmvGdIHvms9DCfb3g4QZA70r448aVpnJQE_ekaRF3cbGjw2r09W0thNud3Rkd2pyamd6bXJkd3FlcQ.9d1eb3dcf0dd50d622e4c88fe7a35ec75ff87e1b&yclid=3362565192360132607&ybaip=1#popup:mygallery'))
    markup.add(types.InlineKeyboardButton('Выбрать случайный напиток со скидкой', callback_data = 'random'))
    markup.add(types.InlineKeyboardButton('Помочь с выбором напитка', callback_data = 'choice'))
    bot.reply_to(message, f'{message.from_user.first_name}, добро пожаловать!{bar_description} \n\nЭтот бот создан для того, чтобы сделать Ваш опыт посещения Imbibe максимально комфортным. С его помощью Вы сможете определиться с выбором напитка по вкусу и настроению или довериться фортуне, выбрав случайный напиток со скидкой 5%!\n\n<i>Для начала работы с ботом, пожалуйста, выберите нужную опцию из меню функций ниже</i>', reply_markup = markup, parse_mode='HTML')

@bot.callback_query_handler(func=lambda callback: True)
def callback_message(callback):
    chat_id = callback.message.chat.id
    if callback.data == 'random':
        user_id = callback.from_user.id
        chat_id = callback.message.chat.id
        today = datetime.now().date().isoformat()
        if user_id in daily_random_drinks and daily_random_drinks[user_id]['date'] == today:
            drink = daily_random_drinks[user_id]['drink']
            msg = f"🎲 На сегодня фортуна уже сделала свой выбор в пользу <b>{drink}</b>!\n\nВозвращайтесь завтра за новым случайным напитком."
            bot.send_message(chat_id, msg, parse_mode='HTML')
        else:
            drink = random.choice(drinks_list).upper()
            daily_random_drinks[user_id] = {'date': today, 'drink': drink}
            filename = re.sub(r'[^a-z0-9]+', '_', drink.lower()).strip('_')
            image = os.path.join(BASE_DIR, "Bot_Cocktails_Pics", f"{filename}.jpg")
            msg = f"🎲 Ваш случайный напиток на сегодня — <b>{drink}</b>!\n\n<i>Предъявите это сообщение на барной стойке, чтобы получить скидку 5%</i>"
            with open(image, 'rb') as file:
                bot.send_photo(chat_id, file, caption=msg, parse_mode='HTML')
    elif callback.data == 'choice':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Крепкий', callback_data='hard'))
        markup.add(types.InlineKeyboardButton('Средней крепости', callback_data='medium'))
        markup.add(types.InlineKeyboardButton('Слабоалкогольный', callback_data='soft'))
        bot.send_message(chat_id, f'Отлично! Ответьте на несколько вопросов о своих предпочтениях, и я подберу коктейль под Ваш вкус.\n\nДля начала, <b>какой крепости вы хотели бы напиток?</b>', reply_markup=markup, parse_mode='HTML')
    
    elif callback.data == 'medium':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Сладкий', callback_data=f'sweet_{callback.data}'))
        markup.add(types.InlineKeyboardButton('Горький', callback_data=f'bitter_{callback.data}'))
        markup.add(types.InlineKeyboardButton('Кислый', callback_data=f'sour_{callback.data}'))
        bot.send_message(chat_id, 'Принято! Теперь давайте определимся <b>с основным вкусом:</b>', reply_markup=markup, parse_mode='HTML')
    elif callback.data == 'soft':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Сладкий', callback_data=f'sweet_{callback.data}'))
        markup.add(types.InlineKeyboardButton('Горький', callback_data=f'bitter_{callback.data}'))
        markup.add(types.InlineKeyboardButton('Кислый', callback_data='TIKTOK ICE TEA'))
        bot.send_message(chat_id, 'Принято! Теперь давайте определимся <b>с основным вкусом:</b>', reply_markup=markup, parse_mode='HTML')
    elif callback.data == 'hard':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Сладкий', callback_data=f'sweet_{callback.data}'))
        markup.add(types.InlineKeyboardButton('Горький', callback_data=f'bitter_{callback.data}'))
        bot.send_message(chat_id, 'Принято! Теперь давайте определимся <b>с основным вкусом:</b>', reply_markup=markup, parse_mode='HTML')
    
    elif callback.data == 'sweet_medium_fruity':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Согревающий', callback_data='PORN PRODUCER'))
        markup.add(types.InlineKeyboardButton('Освежающий', callback_data='sweet_fruity_medium_fresh'))
        bot.send_message(chat_id, 'Почти готово! Выберите, какой <b>эффект</b> Вы ожидаете от напитка:', reply_markup=markup, parse_mode='HTML')
    elif callback.data == 'sweet_medium_spicy':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Согревающий', callback_data='PLUMPOLITAN'))
        markup.add(types.InlineKeyboardButton('Освежающий', callback_data="MY GOD. IT'S GREEN!"))
        bot.send_message(chat_id, 'Почти готово! Выберите, какой <b>эффект</b> Вы ожидаете от напитка:', reply_markup=markup, parse_mode='HTML')
    elif callback.data == 'sweet_medium_berry':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Согревающий', callback_data='STRAWBERRY LAVA'))
        markup.add(types.InlineKeyboardButton('Освежающий', callback_data='RED HEM'))
        bot.send_message(chat_id, 'Почти готово! Выберите, какой <b>эффект</b> Вы ожидаете от напитка:', reply_markup=markup, parse_mode='HTML')
    elif callback.data == 'sweet_fruity_medium_fresh':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Травянистое', callback_data='PEACH PACING'))
        markup.add(types.InlineKeyboardButton('Цитрусовое', callback_data='COCOJITO'))
        markup.add(types.InlineKeyboardButton('Медовое', callback_data='HONEY, MELONI'))
        markup.add(types.InlineKeyboardButton('Тропическое', callback_data='SAWIT TIKI'))
        bot.send_message(chat_id, 'Последний штрих! Какое <b>послевкусие</b> оставляет Ваш напиток?', reply_markup=markup, parse_mode='HTML')
    elif callback.data.startswith('sweet_'):
        strength = callback.data.split('_')[1]
        if strength == 'hard':
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Фруктовые ноты', callback_data='HUMPTY DUMPTY'))
            markup.add(types.InlineKeyboardButton('Пряные ноты', callback_data='DIE HARD'))
            bot.send_message(chat_id, 'Отлично! Какие <b>ноты</b> добавим?', reply_markup=markup, parse_mode='HTML')
        elif strength == 'medium':
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Фруктовые ноты', callback_data='sweet_medium_fruity'))
            markup.add(types.InlineKeyboardButton('Пряные ноты', callback_data='sweet_medium_spicy'))
            markup.add(types.InlineKeyboardButton('Ягодные ноты', callback_data='sweet_medium_berry'))
            bot.send_message(chat_id, 'Отлично! Какие <b>ноты</b> добавим?', reply_markup=markup, parse_mode='HTML')
        else:
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Фруктовые ноты', callback_data='DOUBLE BUBBLE'))
            markup.add(types.InlineKeyboardButton('Ягодные ноты', callback_data='LOLLIPOP 75'))
            bot.send_message(chat_id, 'Отлично! Какие <b>ноты</b> добавим?', reply_markup=markup, parse_mode='HTML')
    
    elif callback.data == 'bitter_spicy_medium':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Согревающий', callback_data='bitter_spicy_medium_warm'))
        markup.add(types.InlineKeyboardButton('Освежающий', callback_data='ITALIAN TOUCH'))
        bot.send_message(chat_id, 'Почти готово! Выберите, какой <b>эффект</b> Вы ожидаете от напитка:', reply_markup=markup, parse_mode='HTML')
    elif callback.data == 'bitter_spicy_medium_warm':
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton('Копченое', callback_data='KALKUTTA COBBLER'))
        markup.add(types.InlineKeyboardButton('Цитрусовое', callback_data='SPANISH BREAKFAST'))
        markup.add(types.InlineKeyboardButton('Овощное', callback_data='FIZZY PEPPY'))
        bot.send_message(chat_id, 'Последний штрих! Какое <b>послевкусие</b> оставляет Ваш напиток?', reply_markup=markup, parse_mode='HTML')
    elif callback.data.startswith('bitter_'):
        strength = callback.data.split('_')[1]
        if strength == 'hard':
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Пряные ноты', callback_data='SMOKY PILL'))
            markup.add(types.InlineKeyboardButton('Классические ноты', callback_data='NEGRONI'))
            bot.send_message(chat_id, 'Отлично! Какие <b>ноты</b> добавим?', reply_markup=markup, parse_mode='HTML')
        elif strength == 'medium':
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Пряные ноты', callback_data='bitter_spicy_medium'))
            markup.add(types.InlineKeyboardButton('Фруктовые ноты', callback_data='ARANCIONI'))
            bot.send_message(chat_id, 'Отлично! Какие <b>ноты</b> добавим?', reply_markup=markup, parse_mode='HTML')
        elif strength == 'soft':
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Пряные ноты', callback_data='BITTER SPARKLE'))
            markup.add(types.InlineKeyboardButton('Классические ноты', callback_data='CAMPARI SPRITZ'))
            bot.send_message(chat_id, 'Отлично! Какие <b>ноты</b> добавим?', reply_markup=markup, parse_mode='HTML')
    
    elif callback.data.startswith('sour_'):
        strength = callback.data.split('_')[1]
        if strength == 'medium':
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Фруктовые ноты', callback_data='SORREL SMASH'))
            markup.add(types.InlineKeyboardButton('Цитрусовые ноты', callback_data="FIG'N'FOAM"))
            markup.add(types.InlineKeyboardButton('Ягодные ноты', callback_data="EASTERN SKY"))
            bot.send_message(chat_id, 'Отлично! Какие <b>ноты</b> добавим?', reply_markup=markup, parse_mode='HTML')
    elif callback.data in drinks_description:
        drink = callback.data
        filename = re.sub(r'[^a-z0-9]+', '_', drink.lower()).strip('_')
        image = os.path.join(BASE_DIR, "Bot_Cocktails_Pics", f"{filename}.jpg")
        features = {
    "Описание": "📝",
    "Состав": "🧊",
    "Крепость": "🥃",
    "Вкусовой профиль": "🍸"
}
        desc = drinks_description[drink]
        text = f'🎉 У Вас прекрасный вкус!\n\nВаш напиток на сегодня — <b>{drink}</b>\n\n'
        for (feature, emoji), value in zip(features.items(), desc):
            text += f"{emoji} <b>{feature}:</b> {value}\n\n"
        with open(image, 'rb') as file:
            bot.send_photo(chat_id, file, caption=text, parse_mode='HTML')
    else:
        bot.send_message(chat_id, "Произошла ошибка. Пожалуйста, начните выбор заново.")
        
bot.polling(none_stop=True)